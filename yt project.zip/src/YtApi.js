import React, { useState } from "react";
import "./App.css";
import getVideoId from "get-video-id";
import millify from "millify";
import web from "../src/logo.png";
import { AiOutlinePlus } from "react-icons/ai";
import { MdOutlineWatchLater } from "react-icons/md";
import { AiOutlineEye } from "react-icons/ai";
import { HiMinus } from "react-icons/hi";

function YtApi() {
  const [share1, setShare] = useState([]);
  const [data1, setData1] = useState("");

  const getData = (e) => {
    setData1(e.target.value);
  };

  const submitData = (e) => {
    e.preventDefault();
    apiGet();
  };

  const deleteyt = (index) => {
    const updateTodo = [...share1].filter((value) => {
      return value !== value;
    });
    setData1("");
    setShare(updateTodo);
  };
  const ytDuration = require("youtube-duration");
  // {
  //   let str = data1;
  //   let equal = str.split("=").pop();
  //   console.log("equal value", equal);
  // }

  const apiGet = async () => {
    await fetch(
      `https://www.googleapis.com/youtube/v3/videos?maxResults=5&id=${
        getVideoId(data1).id
      }&key=AIzaSyB05nncsg-V0LFogZTsM95inqeslHuVOnE&part=snippet,contentDetails,statistics&?_limit=5`
    )
      .then((res) => res.json())
      .then((data) => {
        // console.log("fgsg", data);
        setShare((val) => {
          return [...val, data.items];
        });

        // console.log("data", share1);
      });
  };
  console.log("real data", share1);

  return (
    <>
      <center>
        <img
          src={web}
          style={{ height: "100px", width: "120px", marginTop: "10px" }}
          alt=""
        />
        <h2>Tool to search within video in 2 simple steps:</h2>
        <button className="button1">1</button>_ _ _ _ _ _ _ _ _ _
        <button className="button2">2</button>
        <br />
        <br />
        <h5>
          Select the video channel from youtube. (you can select upto 10 videos
          or 1 channel in this demo version)
        </h5>
        <div className="row">
          <div className="row">
            <div className="col-md-2 drop">
              {/* <div className="dropdown">
                <button
                  className="btn dropdown-toggle"
                  type="button"
                  data-toggle="dropdown"
                >
                  youtube url
                  <span className="caret"></span>
                </button>
                <ul className="dropdown-menu">
                  <li>
                    <a href="/">youtube url</a>
                  </li>
                  <li>
                    <a href="/youtubec">youtube channel</a>
                  </li>
                </ul>
              </div> */}

              <select className="form-select">
                <option selected>Youtube Url</option>

                <option to="/">Youtube Channel</option>

                <option to="/youtubec">youtube Url</option>
              </select>
            </div>
            <div className="col-md-6 mx-5">
              <div className="input-group">
                <input
                  type="text"
                  className="form-control"
                  onChange={getData}
                />
                <button
                  className="btn btn-success"
                  type="submit"
                  onClick={submitData}
                >
                  <AiOutlinePlus />
                </button>
              </div>
            </div>
          </div>
        </div>
      </center>

      <div className="container mt-5">
        <div className="row">
          {share1.length === 0 ? (
            <div></div>
          ) : (
            share1.map((value, index) => {
              {
                /* function convert_time(duration) {
              var a = duration.match(/\d+/g);
              var duration = 0;

              if (a.length === 3) {
                duration = duration + parseInt(a[0]) * 3600;
                duration = duration + parseInt(a[1]) * 60;
                duration = duration + parseInt(a[2]);
              }

              if (a.length === 2) {
                duration = duration + parseInt(a[0]) * 60;
                duration = duration + parseInt(a[1]);
              }

              if (a.length === 1) {
                duration = duration + parseInt(a[0]);
              }
              return duration;
            } */
              }
              var count = millify(share1[index][0]?.statistics?.viewCount);
              return (
                <>
                  <div
                    className="card gy-4 "
                    style={{
                      width: "15rem",
                      marginLeft: "14px",
                      objectFit: "cover",
                    }}
                  >
                    <div className="button4" onClick={() => deleteyt(index)}>
                      <HiMinus />
                    </div>
                    <img
                      src={share1[index][0]?.snippet?.thumbnails?.high.url}
                      className="card-img-top"
                      style={{ objectFit: "cover" }}
                      alt="..."
                    />

                    <h5>{share1[index][0]?.snippet?.title}</h5>
                    <div className="row">
                      <div className="col-md-6">
                        <p className="card-title">
                          <MdOutlineWatchLater />
                          {ytDuration.format(
                            share1[index][0]?.contentDetails?.duration
                          )}
                        </p>
                      </div>
                      <div className="col-md-6 manage ">
                        <p className="card-title">
                          <AiOutlineEye />
                          {count}
                        </p>
                      </div>
                    </div>
                  </div>
                </>
              );
            })
          )}
        </div>
      </div>
    </>
  );
}
export default YtApi;

// [...val, items.items];
